var group___e_f_m32_g230_f128___d_m_a =
[
    [ "DMA_TypeDef", "d5/df6/struct_d_m_a___type_def.html", [
      [ "STATUS", "d5/df6/struct_d_m_a___type_def.html#aece2c880dc5ba01a2fc9326dc080dc26", null ],
      [ "CONFIG", "d5/df6/struct_d_m_a___type_def.html#ae60e13777d050ba31d6c76e5f0ff7afe", null ],
      [ "CTRLBASE", "d5/df6/struct_d_m_a___type_def.html#a644fe131f855a510c5c0fc9421368ff2", null ],
      [ "ALTCTRLBASE", "d5/df6/struct_d_m_a___type_def.html#a6d6d797c08f3f0e3e66746562760d521", null ],
      [ "CHWAITSTATUS", "d5/df6/struct_d_m_a___type_def.html#a0d2e2439db22f946bedc15ae857f2b29", null ],
      [ "CHSWREQ", "d5/df6/struct_d_m_a___type_def.html#a85f3456282001bc78fd78ba0a09d7e90", null ],
      [ "CHUSEBURSTS", "d5/df6/struct_d_m_a___type_def.html#abc54387cc709be547afdb0de696fef53", null ],
      [ "CHUSEBURSTC", "d5/df6/struct_d_m_a___type_def.html#a7aa9cd78cc28a61b3d6fe53fda58edd9", null ],
      [ "CHREQMASKS", "d5/df6/struct_d_m_a___type_def.html#ab0ff34a1a97ff137625b365155d1d51f", null ],
      [ "CHREQMASKC", "d5/df6/struct_d_m_a___type_def.html#a3dc75dba6ee68fefaa70822c12f620fe", null ],
      [ "CHENS", "d5/df6/struct_d_m_a___type_def.html#af7a15d184f96d420ee7aeb19bbf569eb", null ],
      [ "CHENC", "d5/df6/struct_d_m_a___type_def.html#afc00d8948500909008eef87482073352", null ],
      [ "CHALTS", "d5/df6/struct_d_m_a___type_def.html#a8667dcb90238d86aed55bb30758c2182", null ],
      [ "CHALTC", "d5/df6/struct_d_m_a___type_def.html#afb2ec50039fcda7c819bdc90abc2310e", null ],
      [ "CHPRIS", "d5/df6/struct_d_m_a___type_def.html#ae4cda5e12ed8fcc9519542de883005d5", null ],
      [ "CHPRIC", "d5/df6/struct_d_m_a___type_def.html#a810dc3de4f96f08e62af065ebb34f368", null ],
      [ "RESERVED0", "d5/df6/struct_d_m_a___type_def.html#a8d5872ef46261e096eae509eec8bc5c3", null ],
      [ "ERRORC", "d5/df6/struct_d_m_a___type_def.html#a1d2108fac600d194f37afee55485e922", null ],
      [ "RESERVED1", "d5/df6/struct_d_m_a___type_def.html#ad48b34a9ec67f8e711e5967a40953f7a", null ],
      [ "CHREQSTATUS", "d5/df6/struct_d_m_a___type_def.html#a4b46a37af82f8c8ea85b7baafbd66aeb", null ],
      [ "RESERVED2", "d5/df6/struct_d_m_a___type_def.html#a032c71ff46a97d2398e5c15a1b4fa50d", null ],
      [ "CHSREQSTATUS", "d5/df6/struct_d_m_a___type_def.html#a6bea6f879b40cd424fb44006532dc9e6", null ],
      [ "RESERVED3", "d5/df6/struct_d_m_a___type_def.html#a9318f2e45b94376170ff6c2b34fcf160", null ],
      [ "IF", "d5/df6/struct_d_m_a___type_def.html#a845b107a946fce4c9b03439572ea04d4", null ],
      [ "IFS", "d5/df6/struct_d_m_a___type_def.html#a03ef35796daa090d53e00c760a77f465", null ],
      [ "IFC", "d5/df6/struct_d_m_a___type_def.html#ae65f635e21c1984d0acb3f2f5a2b6cc4", null ],
      [ "IEN", "d5/df6/struct_d_m_a___type_def.html#aa6cf929795f536b4187f4238d0ded2ae", null ],
      [ "RESERVED4", "d5/df6/struct_d_m_a___type_def.html#a22e089cb477ed397c453e0298adb7025", null ],
      [ "CH", "d5/df6/struct_d_m_a___type_def.html#a0ed2ab62bd30868d0ae59715dff88ca7", null ]
    ] ]
];