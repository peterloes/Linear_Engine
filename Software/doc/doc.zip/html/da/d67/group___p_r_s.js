var group___p_r_s =
[
    [ "PRS_Edge_TypeDef", "da/d67/group___p_r_s.html#ga853e2a53ed99eb3a0c5e163e1d33e814", [
      [ "prsEdgeOff", "da/d67/group___p_r_s.html#gga853e2a53ed99eb3a0c5e163e1d33e814adaedb771c597b00faf88f2824635d121", null ],
      [ "prsEdgePos", "da/d67/group___p_r_s.html#gga853e2a53ed99eb3a0c5e163e1d33e814adbd6e92bf78e77be0dc3308f593938a8", null ],
      [ "prsEdgeNeg", "da/d67/group___p_r_s.html#gga853e2a53ed99eb3a0c5e163e1d33e814a481c2c2199b2c728b0c6a80940951ddd", null ],
      [ "prsEdgeBoth", "da/d67/group___p_r_s.html#gga853e2a53ed99eb3a0c5e163e1d33e814ad4d7a0309f26341e3ff3a2c52c0be708", null ]
    ] ],
    [ "PRS_LevelSet", "da/d67/group___p_r_s.html#ga9fe2bc6548ee63f233cb706920d97b4e", null ],
    [ "PRS_PulseTrigger", "da/d67/group___p_r_s.html#gabf5756623b5b766e287ca27441bd0f1d", null ],
    [ "PRS_SourceSignalSet", "da/d67/group___p_r_s.html#gab8273dde832f46d40696b4c5025e411c", null ]
];