var struct_i2_c___init___type_def =
[
    [ "enable", "df/d24/struct_i2_c___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "master", "df/d24/struct_i2_c___init___type_def.html#a076a973bb9631a8e8a5fe1452f01f0bc", null ],
    [ "refFreq", "df/d24/struct_i2_c___init___type_def.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "freq", "df/d24/struct_i2_c___init___type_def.html#aacfad457f5366fa9265eb0a89e43f23b", null ],
    [ "clhr", "df/d24/struct_i2_c___init___type_def.html#a21fe116060fe1e7dcefef7e0114b18bd", null ]
];