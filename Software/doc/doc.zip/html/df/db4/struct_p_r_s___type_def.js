var struct_p_r_s___type_def =
[
    [ "SWPULSE", "df/db4/struct_p_r_s___type_def.html#a8941a9078b35d7c01b50911620fe9261", null ],
    [ "SWLEVEL", "df/db4/struct_p_r_s___type_def.html#a35eb80dce09e234c533a246191813f59", null ],
    [ "RESERVED0", "df/db4/struct_p_r_s___type_def.html#a8be676577db129a84a9a2689519a8502", null ],
    [ "CH", "df/db4/struct_p_r_s___type_def.html#a778142498464890df170578ab8cff401", null ]
];