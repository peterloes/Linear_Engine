var struct_m_p_u___region_init___type_def =
[
    [ "regionEnable", "dd/db1/struct_m_p_u___region_init___type_def.html#a96a6f2ab70abaa3dd09be9affacf177e", null ],
    [ "regionNo", "dd/db1/struct_m_p_u___region_init___type_def.html#a3ae39a1f68a83100e07c397614666743", null ],
    [ "baseAddress", "dd/db1/struct_m_p_u___region_init___type_def.html#a2dcd4c60762d1d8e8402470b7958b24c", null ],
    [ "size", "dd/db1/struct_m_p_u___region_init___type_def.html#a5101b5ef1adfceee0ec4fa75c97ad915", null ],
    [ "accessPermission", "dd/db1/struct_m_p_u___region_init___type_def.html#a5966a91d4cff29342c5af4e26a5af04f", null ],
    [ "disableExec", "dd/db1/struct_m_p_u___region_init___type_def.html#a8275b7fd6eebb9e537c60256a0d43125", null ],
    [ "shareable", "dd/db1/struct_m_p_u___region_init___type_def.html#a8595b2218cf2d99d0987a204f511f3f2", null ],
    [ "cacheable", "dd/db1/struct_m_p_u___region_init___type_def.html#a26c22ff8667ca49e2fab513045b4f8fd", null ],
    [ "bufferable", "dd/db1/struct_m_p_u___region_init___type_def.html#aa55ef438857c8c77ace5835b15c2c4aa", null ],
    [ "srd", "dd/db1/struct_m_p_u___region_init___type_def.html#a4cc51c2ea30fe809470dfcb75cadfc07", null ],
    [ "tex", "dd/db1/struct_m_p_u___region_init___type_def.html#a5ff87f09a2248f5b465f6b405b904979", null ]
];