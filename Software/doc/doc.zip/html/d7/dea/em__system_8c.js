var em__system_8c =
[
    [ "SYSTEM_ChipRevisionGet", "dd/d1a/group___s_y_s_t_e_m.html#ga6470ed38937ffd0b8b509334c5add7dd", null ],
    [ "SYSTEM_GetCalibrationValue", "dd/d1a/group___s_y_s_t_e_m.html#ga786913c991338e29650617d89aec3768", null ]
];