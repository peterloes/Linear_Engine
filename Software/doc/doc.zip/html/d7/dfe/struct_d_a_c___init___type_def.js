var struct_d_a_c___init___type_def =
[
    [ "refresh", "d7/dfe/struct_d_a_c___init___type_def.html#a32e9b42471a1d0f843756175ca23f404", null ],
    [ "reference", "d7/dfe/struct_d_a_c___init___type_def.html#ac41d9dd2654ba939f5d096bc82e842d6", null ],
    [ "outMode", "d7/dfe/struct_d_a_c___init___type_def.html#a34a218bf2a8f0301c1160a6ef2d9b38f", null ],
    [ "convMode", "d7/dfe/struct_d_a_c___init___type_def.html#af3850bf681474674537b5a9d60e190ca", null ],
    [ "prescale", "d7/dfe/struct_d_a_c___init___type_def.html#ad4f9eb028b4dee0645920af8f0d86df9", null ],
    [ "lpEnable", "d7/dfe/struct_d_a_c___init___type_def.html#a583850bd95a39ebeea97d16f11c1a6c1", null ],
    [ "ch0ResetPre", "d7/dfe/struct_d_a_c___init___type_def.html#a91efb2741d91892c100822c7c5617810", null ],
    [ "outEnablePRS", "d7/dfe/struct_d_a_c___init___type_def.html#a0c1d1ef0fb6ed53093d2edcc43137777", null ],
    [ "sineEnable", "d7/dfe/struct_d_a_c___init___type_def.html#a3fd03c4b946bf7c449323857b6834d73", null ],
    [ "diff", "d7/dfe/struct_d_a_c___init___type_def.html#a73c8af0fb78a0c12a7b9eb6f0f397f4f", null ]
];