var group___v_c_m_p =
[
    [ "VCMP_Init_TypeDef", "dc/d4f/struct_v_c_m_p___init___type_def.html", [
      [ "halfBias", "dc/d4f/struct_v_c_m_p___init___type_def.html#acbb92db3a14fd71e0eb0d0fd9d9df89b", null ],
      [ "biasProg", "dc/d4f/struct_v_c_m_p___init___type_def.html#adbd3aea64f5e709d49fe2d3aa851c833", null ],
      [ "irqFalling", "dc/d4f/struct_v_c_m_p___init___type_def.html#a2ab8cde23c7a4da3b355ce74331c6262", null ],
      [ "irqRising", "dc/d4f/struct_v_c_m_p___init___type_def.html#a7c8cde290b136a861c3b411aa02f6c98", null ],
      [ "warmup", "dc/d4f/struct_v_c_m_p___init___type_def.html#a15a0ec7e11b0788caa3e985e8f0881da", null ],
      [ "hyst", "dc/d4f/struct_v_c_m_p___init___type_def.html#a4fee887b8fb28edc0349c68479ab46cc", null ],
      [ "inactive", "dc/d4f/struct_v_c_m_p___init___type_def.html#ab9f8cb1474be2bd57a5704f04887609d", null ],
      [ "lowPowerRef", "dc/d4f/struct_v_c_m_p___init___type_def.html#aef0753f3615cc32db3490c129df6fd2d", null ],
      [ "triggerLevel", "dc/d4f/struct_v_c_m_p___init___type_def.html#a68cad0dddfb1adccebad6f166585337b", null ],
      [ "enable", "dc/d4f/struct_v_c_m_p___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ]
    ] ],
    [ "VCMP_INIT_DEFAULT", "d4/d35/group___v_c_m_p.html#ga52b01f1cadf892c8ec22e9ce4106b360", null ],
    [ "VCMP_WarmTime_TypeDef", "d4/d35/group___v_c_m_p.html#ga4d4b37ff688f47766c7f11fd44806cc6", [
      [ "vcmpWarmTime4Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6aa18bd07e3b064e80f710772c03ef6e16", null ],
      [ "vcmpWarmTime8Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6ab833ea0316d2729f828f44b3ebe2b4ba", null ],
      [ "vcmpWarmTime16Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a0c3463a3df83eb595683def4fa3e191e", null ],
      [ "vcmpWarmTime32Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a40c1933761b44df612af15901ba3b3bd", null ],
      [ "vcmpWarmTime64Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a7f759bfc3a0cd6061c9e56de13f90049", null ],
      [ "vcmpWarmTime128Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a303d98df3d98f8f9cdb25e0a701e278b", null ],
      [ "vcmpWarmTime256Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a0629f788c0d6c46e0bc61a1890c7a927", null ],
      [ "vcmpWarmTime512Cycles", "d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a3a70a500a360e8e46e0e27ff8d245061", null ]
    ] ],
    [ "VCMP_Hysteresis_TypeDef", "d4/d35/group___v_c_m_p.html#gab56ac68a10865bcbd08f2978a6cf5d5b", [
      [ "vcmpHystNone", "d4/d35/group___v_c_m_p.html#ggab56ac68a10865bcbd08f2978a6cf5d5ba206e40abcd9cb83626a9ca4b4120c629", null ],
      [ "vcmpHyst20mV", "d4/d35/group___v_c_m_p.html#ggab56ac68a10865bcbd08f2978a6cf5d5ba9c7ff466e5d4da40fcd034d880f0b334", null ]
    ] ],
    [ "VCMP_Init", "d4/d35/group___v_c_m_p.html#ga52aa53df539c0d68c1e2e0f5b4b40041", null ],
    [ "VCMP_LowPowerRefSet", "d4/d35/group___v_c_m_p.html#gab87bb21a4afe57c7721d424e2f8e99c5", null ],
    [ "VCMP_TriggerSet", "d4/d35/group___v_c_m_p.html#ga185203f0a0c2e0343cca51d82b2b21ef", null ],
    [ "VCMP_Enable", "d4/d35/group___v_c_m_p.html#gacd1e72c9db56316c049efb14e3aa2fc2", null ],
    [ "VCMP_Disable", "d4/d35/group___v_c_m_p.html#ga4d05b8a07f535aea84df53ffcc0904da", null ],
    [ "VCMP_VoltageToLevel", "d4/d35/group___v_c_m_p.html#ga90bc9473c20571d6a6938b3afbdd26c7", null ],
    [ "VCMP_VDDLower", "d4/d35/group___v_c_m_p.html#gac052041a40fe31b2d6b6536628674b24", null ],
    [ "VCMP_VDDHigher", "d4/d35/group___v_c_m_p.html#ga9ec536ab9b943fcf5c1ec34feb951f13", null ],
    [ "VCMP_Ready", "d4/d35/group___v_c_m_p.html#ga8ded00997c333fd43ebb3c5ad888bac7", null ],
    [ "VCMP_IntClear", "d4/d35/group___v_c_m_p.html#ga90c047e9c776cad27065458add1486fd", null ],
    [ "VCMP_IntSet", "d4/d35/group___v_c_m_p.html#ga4f19b07662931f087951ba5ff5af1189", null ],
    [ "VCMP_IntDisable", "d4/d35/group___v_c_m_p.html#ga67704d1b4bfa3b74f0a5991efc64ef6d", null ],
    [ "VCMP_IntEnable", "d4/d35/group___v_c_m_p.html#gaf52eef153dec125bcc731ad0d31e3f11", null ],
    [ "VCMP_IntGet", "d4/d35/group___v_c_m_p.html#ga2c95d208b80bffc906fef5c3bcdeacc8", null ],
    [ "VCMP_IntGetEnabled", "d4/d35/group___v_c_m_p.html#gaffed33ef4b644cd0f52bf99613012473", null ]
];