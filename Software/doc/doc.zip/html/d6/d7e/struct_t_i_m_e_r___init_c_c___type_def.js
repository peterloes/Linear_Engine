var struct_t_i_m_e_r___init_c_c___type_def =
[
    [ "eventCtrl", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a717226d827e446f4dfd84c548c3951d9", null ],
    [ "edge", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a65d07222ef1e7e9f7abdfee469bc6343", null ],
    [ "prsSel", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a7aaeb6b35db314899c4cde40730d2d79", null ],
    [ "cufoa", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a71bd54802b46f0c1094031e9f5ae8428", null ],
    [ "cofoa", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a058a4818cfdd6faeb917375b544e0d2c", null ],
    [ "cmoa", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#ab21efeb4abd2c74c13fa8170e8a88597", null ],
    [ "mode", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#ac25045bc4fd6e60d69c1bc27f9638a17", null ],
    [ "filter", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a5b85fc472953eac39c2629b1f5d68617", null ],
    [ "prsInput", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a5ad024f9fd9c19bdca305ccc522051f4", null ],
    [ "coist", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a547aea6a5c8d23cc79e243bc33b04929", null ],
    [ "outInvert", "d6/d7e/struct_t_i_m_e_r___init_c_c___type_def.html#a5a65c6bf32ae4e70488c6ecf6adc9539", null ]
];