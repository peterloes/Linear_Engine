var group___a_d_c =
[
    [ "ADC_Init_TypeDef", "da/db8/struct_a_d_c___init___type_def.html", [
      [ "ovsRateSel", "da/db8/struct_a_d_c___init___type_def.html#ae389a7355302182f5fde2bec22ee74df", null ],
      [ "lpfMode", "da/db8/struct_a_d_c___init___type_def.html#ad2d472ec9fc001bdd56a4f17798b6886", null ],
      [ "warmUpMode", "da/db8/struct_a_d_c___init___type_def.html#a1e1b138d01ac6d7b311c343d319dda2c", null ],
      [ "timebase", "da/db8/struct_a_d_c___init___type_def.html#a2e2753c2dee3e558e653c99e687282f0", null ],
      [ "prescale", "da/db8/struct_a_d_c___init___type_def.html#ad4f9eb028b4dee0645920af8f0d86df9", null ],
      [ "tailgate", "da/db8/struct_a_d_c___init___type_def.html#af8b1963210351bce0efe576cbdb0e4b8", null ]
    ] ],
    [ "ADC_InitScan_TypeDef", "dd/d7e/struct_a_d_c___init_scan___type_def.html", [
      [ "prsSel", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a7a41217e015b147a659fdecacf2e74c8", null ],
      [ "acqTime", "dd/d7e/struct_a_d_c___init_scan___type_def.html#aa26492a8e94f1c35b1af3808e459007b", null ],
      [ "reference", "dd/d7e/struct_a_d_c___init_scan___type_def.html#add502b6cd8083f28f70e2793ce7c33e8", null ],
      [ "resolution", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a1e407416a9c7a57da01413115a32c0f7", null ],
      [ "input", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a237ac13643964d05d26f13a42e1543b3", null ],
      [ "diff", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a73c8af0fb78a0c12a7b9eb6f0f397f4f", null ],
      [ "prsEnable", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a78606b3fad672fa22c1f11625fdc25ec", null ],
      [ "leftAdjust", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a6acfde7148d88a62f39fcb5660dd2678", null ],
      [ "rep", "dd/d7e/struct_a_d_c___init_scan___type_def.html#ad95946ad100922534b1a63d4a6ebe897", null ]
    ] ],
    [ "ADC_InitSingle_TypeDef", "d4/da3/struct_a_d_c___init_single___type_def.html", [
      [ "prsSel", "d4/da3/struct_a_d_c___init_single___type_def.html#a7a41217e015b147a659fdecacf2e74c8", null ],
      [ "acqTime", "d4/da3/struct_a_d_c___init_single___type_def.html#aa26492a8e94f1c35b1af3808e459007b", null ],
      [ "reference", "d4/da3/struct_a_d_c___init_single___type_def.html#add502b6cd8083f28f70e2793ce7c33e8", null ],
      [ "resolution", "d4/da3/struct_a_d_c___init_single___type_def.html#a1e407416a9c7a57da01413115a32c0f7", null ],
      [ "input", "d4/da3/struct_a_d_c___init_single___type_def.html#aa54bf90bc8115afd115aaf642b249738", null ],
      [ "diff", "d4/da3/struct_a_d_c___init_single___type_def.html#a73c8af0fb78a0c12a7b9eb6f0f397f4f", null ],
      [ "prsEnable", "d4/da3/struct_a_d_c___init_single___type_def.html#a78606b3fad672fa22c1f11625fdc25ec", null ],
      [ "leftAdjust", "d4/da3/struct_a_d_c___init_single___type_def.html#a6acfde7148d88a62f39fcb5660dd2678", null ],
      [ "rep", "d4/da3/struct_a_d_c___init_single___type_def.html#ad95946ad100922534b1a63d4a6ebe897", null ]
    ] ],
    [ "ADC_INIT_DEFAULT", "db/d78/group___a_d_c.html#ga4572f863a8d863214dfd0a4b48f653e2", null ],
    [ "ADC_INITSCAN_DEFAULT", "db/d78/group___a_d_c.html#gabe964e6cb872ec50ada2c37331a0176d", null ],
    [ "ADC_INITSINGLE_DEFAULT", "db/d78/group___a_d_c.html#ga1a0cd333a457f356692138fcf3b2275e", null ],
    [ "ADC_AcqTime_TypeDef", "db/d78/group___a_d_c.html#ga85e06060d63f1b16039d8efa318833d4", [
      [ "adcAcqTime1", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4a8ce5aa42e27cab1c6155b432a65674c9", null ],
      [ "adcAcqTime2", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4a52e795b2a9f0380c6e54a036ba54de61", null ],
      [ "adcAcqTime4", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4a53b36bb13295813038ca8e4255afe5ba", null ],
      [ "adcAcqTime8", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4afe09c849dd87615220d82b0487aad91a", null ],
      [ "adcAcqTime16", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4af89189f3703754e763232cee87ff6c24", null ],
      [ "adcAcqTime32", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4ac560c44751f65f3e187dba2f8811d139", null ],
      [ "adcAcqTime64", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4aa94cb1da1b7ce8b7afbdca8e5d5a1764", null ],
      [ "adcAcqTime128", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4aa33bcad0e6e0606b74d071214e4ea472", null ],
      [ "adcAcqTime256", "db/d78/group___a_d_c.html#gga85e06060d63f1b16039d8efa318833d4ab6647a38bf29c66f96ca46d8d7c4fc0a", null ]
    ] ],
    [ "ADC_LPFilter_TypeDef", "db/d78/group___a_d_c.html#ga3fc7e4aa2fb8d028f622e93e7bea3055", [
      [ "adcLPFilterBypass", "db/d78/group___a_d_c.html#gga3fc7e4aa2fb8d028f622e93e7bea3055af2118fc83283bac43666b83478e7f500", null ],
      [ "adcLPFilterRC", "db/d78/group___a_d_c.html#gga3fc7e4aa2fb8d028f622e93e7bea3055adb0474cf95be3060f65bd61f50fd8c7b", null ],
      [ "adcLPFilterDeCap", "db/d78/group___a_d_c.html#gga3fc7e4aa2fb8d028f622e93e7bea3055a135665f12a680888eeaeba3baa4a9f94", null ]
    ] ],
    [ "ADC_OvsRateSel_TypeDef", "db/d78/group___a_d_c.html#gaaeb1f1d92bdb6a1bfc824461d63f5a21", [
      [ "adcOvsRateSel2", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a7b09ccd08d771af9008f378a19c63d57", null ],
      [ "adcOvsRateSel4", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a743dd5cf31c637824a9b90523bef4770", null ],
      [ "adcOvsRateSel8", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a984156afa02a3b77a8e59b81f4a9cd27", null ],
      [ "adcOvsRateSel16", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a9bfbde4168c331298362bd531e696f78", null ],
      [ "adcOvsRateSel32", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21ac34f68fb882994a8b8eaeea39b1f3ace", null ],
      [ "adcOvsRateSel64", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a683d37f014f77696e67f21d2a457d4e2", null ],
      [ "adcOvsRateSel128", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a72436f829063642c2f48414fc3d09690", null ],
      [ "adcOvsRateSel256", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a5f4717c87f7937ed8c69d9f5cc82c6cd", null ],
      [ "adcOvsRateSel512", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a69f9a4460d7dc6bc27f480dceed39f23", null ],
      [ "adcOvsRateSel1024", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a98c481dd9988480ff223a8ad7a389e85", null ],
      [ "adcOvsRateSel2048", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21a32293790619576912ad20f57e773154a", null ],
      [ "adcOvsRateSel4096", "db/d78/group___a_d_c.html#ggaaeb1f1d92bdb6a1bfc824461d63f5a21aefbac494813347ff3a59ae652f990edf", null ]
    ] ],
    [ "ADC_PRSSEL_TypeDef", "db/d78/group___a_d_c.html#gacc4ddb8213b64d8b89df372069003b49", [
      [ "adcPRSSELCh0", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a508b578219d0a3a6df78382dcd48d8de", null ],
      [ "adcPRSSELCh1", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a7b590cf50b87609abf44e29c1fc68d84", null ],
      [ "adcPRSSELCh2", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a97a693c167f17958177fe0af25bc44c9", null ],
      [ "adcPRSSELCh3", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a2deebb3587f3d7ea30fdccc46bb144e4", null ],
      [ "adcPRSSELCh4", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49acc8175ffc4743f966c00cc8c53a487af", null ],
      [ "adcPRSSELCh5", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a1c79047d352bacc210640a636e574257", null ],
      [ "adcPRSSELCh6", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a9d13c48296f38a54ae1c38df32c34566", null ],
      [ "adcPRSSELCh7", "db/d78/group___a_d_c.html#ggacc4ddb8213b64d8b89df372069003b49a0a59c3e3fd1d246d601f0d707b34a63e", null ]
    ] ],
    [ "ADC_Ref_TypeDef", "db/d78/group___a_d_c.html#ga90e3c5bfd7ebdd7686cf65bb896e4eac", [
      [ "adcRef1V25", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eaca97f40de792c64102ddbf60b0faa82c32", null ],
      [ "adcRef2V5", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eaca611947cfb4d734ac07e6d44967ca28ce", null ],
      [ "adcRefVDD", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eaca875ace9b639af0d1640e8c597ddf7c0d", null ],
      [ "adcRef5VDIFF", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eacab8fa2a2f4bc48d4f5e46173714288fca", null ],
      [ "adcRefExtSingle", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eacaf8fc4b0a067f7002d9cf4350de5342aa", null ],
      [ "adcRef2xExtDiff", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eacafb73c669d8537f2afc679f2910827805", null ],
      [ "adcRef2xVDD", "db/d78/group___a_d_c.html#gga90e3c5bfd7ebdd7686cf65bb896e4eaca85d6fcd5c42fbc583bb02eb5374cd702", null ]
    ] ],
    [ "ADC_Res_TypeDef", "db/d78/group___a_d_c.html#ga0e5f9f20d16acc591c7329302f562f10", [
      [ "adcRes12Bit", "db/d78/group___a_d_c.html#gga0e5f9f20d16acc591c7329302f562f10a046959365e8be6caa6d26739f37c3bc8", null ],
      [ "adcRes8Bit", "db/d78/group___a_d_c.html#gga0e5f9f20d16acc591c7329302f562f10a9e465cd1c3fadde745a72875ae424a1b", null ],
      [ "adcRes6Bit", "db/d78/group___a_d_c.html#gga0e5f9f20d16acc591c7329302f562f10a4e2b35830cf9430251ecf3959af6f04c", null ],
      [ "adcResOVS", "db/d78/group___a_d_c.html#gga0e5f9f20d16acc591c7329302f562f10a81037a34c35c126216119c80b11e7b78", null ]
    ] ],
    [ "ADC_SingleInput_TypeDef", "db/d78/group___a_d_c.html#ga35d458714c6cb3a1d08586aadcb30eba", [
      [ "adcSingleInpCh0", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa448a380d003de28626a1702e88f31f74", null ],
      [ "adcSingleInpCh1", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa6db284872754b2a0aaaaae4eba60d8c5", null ],
      [ "adcSingleInpCh2", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaaf52903d33f54eccd1f36539a9d11369c", null ],
      [ "adcSingleInpCh3", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaafdb479fa62e83c0120e0e55d7c340e55", null ],
      [ "adcSingleInpCh4", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa5fcc062d4339f6e776af022f28ef7049", null ],
      [ "adcSingleInpCh5", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa9a9e3d920d7f0138be1c1e3a8c1d9330", null ],
      [ "adcSingleInpCh6", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa893c967219beb3dd595581b687021d72", null ],
      [ "adcSingleInpCh7", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa55a4cacf21e12a105fd7fc0712a4a68a", null ],
      [ "adcSingleInpTemp", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa1c4182b40eb6061022cf1b8627f42a42", null ],
      [ "adcSingleInpVDDDiv3", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa7131e28acd1a8c3ec0728a8d1c658cd5", null ],
      [ "adcSingleInpVDD", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaadad4c564d3a1c3960f7c7b1005765e62", null ],
      [ "adcSingleInpVSS", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa8523942b7a62bee6c8946c77faa870ae", null ],
      [ "adcSingleInpVrefDiv2", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaaa143149f11ac822c10bd3850f6f564c9", null ],
      [ "adcSingleInpDACOut0", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaac4395f6abce31d4c5c12f54e9e1cade0", null ],
      [ "adcSingleInpDACOut1", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa6656a488dde2bc189a67e0ac590fd85c", null ],
      [ "adcSingleInpATEST", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa53676a8ecabf33a228dae21a1f80e2d5", null ],
      [ "adcSingleInpCh0Ch1", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa82b0e50a45e993b12bd3d430b46622be", null ],
      [ "adcSingleInpCh2Ch3", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaad953f487b445f7f113bb078c597c83a9", null ],
      [ "adcSingleInpCh4Ch5", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa5dbe97ecf2d6067624fed8d33a804d71", null ],
      [ "adcSingleInpCh6Ch7", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa35660c1da6bbbe56069d13c115af1c43", null ],
      [ "adcSingleInpDiff0", "db/d78/group___a_d_c.html#gga35d458714c6cb3a1d08586aadcb30ebaa4555d11730de2da4f1ef7cb533522731", null ]
    ] ],
    [ "ADC_Start_TypeDef", "db/d78/group___a_d_c.html#gabb2bed27705f116f042670adb36996fb", [
      [ "adcStartSingle", "db/d78/group___a_d_c.html#ggabb2bed27705f116f042670adb36996fbae6bdebdccc5c1edc843c906ab5929cae", null ],
      [ "adcStartScan", "db/d78/group___a_d_c.html#ggabb2bed27705f116f042670adb36996fbaeb2f8b1e59f1058616d3276a5e25e77b", null ],
      [ "adcStartScanAndSingle", "db/d78/group___a_d_c.html#ggabb2bed27705f116f042670adb36996fbae364da4dad2dbd7170908eb29e77749d", null ]
    ] ],
    [ "ADC_Warmup_TypeDef", "db/d78/group___a_d_c.html#ga3990fbf520d66567df3de07ac040d6c5", [
      [ "adcWarmupNormal", "db/d78/group___a_d_c.html#gga3990fbf520d66567df3de07ac040d6c5a0b495546dd9a182c1c0867d48a3162ca", null ],
      [ "adcWarmupFastBG", "db/d78/group___a_d_c.html#gga3990fbf520d66567df3de07ac040d6c5af43b484aa6578a355b2457786570fa46", null ],
      [ "adcWarmupKeepScanRefWarm", "db/d78/group___a_d_c.html#gga3990fbf520d66567df3de07ac040d6c5a1442ad8a26e94dd6ec37e3348515e771", null ],
      [ "adcWarmupKeepADCWarm", "db/d78/group___a_d_c.html#gga3990fbf520d66567df3de07ac040d6c5abfde4333060e0f79b1a4ec3076a75ee2", null ]
    ] ],
    [ "ADC_DataSingleGet", "db/d78/group___a_d_c.html#gad88086368d3a6ddd2ca71503da68607b", null ],
    [ "ADC_DataScanGet", "db/d78/group___a_d_c.html#ga16bbb8a7a2a4304a9b5233ff5e55dceb", null ],
    [ "ADC_Init", "db/d78/group___a_d_c.html#ga3d5a968fbc40b29ebc05f17b311f2eb9", null ],
    [ "ADC_InitScan", "db/d78/group___a_d_c.html#ga41207273ca90e4173084233060e0edbb", null ],
    [ "ADC_InitSingle", "db/d78/group___a_d_c.html#ga76aa8949d51eb1027906f68b0952ea0e", null ],
    [ "ADC_IntClear", "db/d78/group___a_d_c.html#ga8519f6d9482a6fb6a15365f62fc4435d", null ],
    [ "ADC_IntDisable", "db/d78/group___a_d_c.html#ga4e7612b7ab98ff06627cd121d51da1dc", null ],
    [ "ADC_IntEnable", "db/d78/group___a_d_c.html#ga98bf6f1584f8879dd9d0118afd78e240", null ],
    [ "ADC_IntGet", "db/d78/group___a_d_c.html#ga672d01dc9249a61c1b294a6849d5e55a", null ],
    [ "ADC_IntSet", "db/d78/group___a_d_c.html#ga9538560672ae862a2fc339ce7c7999b9", null ],
    [ "ADC_PrescaleCalc", "db/d78/group___a_d_c.html#ga635eb5e70c406ff3bd150b8e695a70f9", null ],
    [ "ADC_Start", "db/d78/group___a_d_c.html#ga9dbf010db18a514043b369886de0bfc7", null ],
    [ "ADC_Reset", "db/d78/group___a_d_c.html#ga75639a8eba9a3353c216b324e554827e", null ],
    [ "ADC_TimebaseCalc", "db/d78/group___a_d_c.html#ga95a5a908501b6c3bbd44022d41205e73", null ]
];