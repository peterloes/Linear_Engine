var em__wdog_8h =
[
    [ "WDOG_INIT_DEFAULT", "dc/dc9/group___w_d_o_g.html#ga8169ae345fecb9d7abddeb495db92693", null ],
    [ "WDOG_ClkSel_TypeDef", "dc/dc9/group___w_d_o_g.html#ga84959950c7a90940b7b2aa414648f338", [
      [ "wdogClkSelULFRCO", "dc/dc9/group___w_d_o_g.html#gga84959950c7a90940b7b2aa414648f338a13e2668aa9503395dece59d8ed08e468", null ],
      [ "wdogClkSelLFRCO", "dc/dc9/group___w_d_o_g.html#gga84959950c7a90940b7b2aa414648f338a4bf588ad917693cc867dbde173d7a090", null ],
      [ "wdogClkSelLFXO", "dc/dc9/group___w_d_o_g.html#gga84959950c7a90940b7b2aa414648f338a4277fbeff57cbd111bc2b6df49dc17f7", null ]
    ] ],
    [ "WDOG_PeriodSel_TypeDef", "dc/dc9/group___w_d_o_g.html#gafb32176c669596071269d5fe62734505", [
      [ "wdogPeriod_9", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a9ed45af9c6fd5b2d8e3f205b448755d1", null ],
      [ "wdogPeriod_17", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505aa813473bdb90f90ccebcc4220ebaf99b", null ],
      [ "wdogPeriod_33", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a13f8ceefd730aea4db809cb5b3a2cafa", null ],
      [ "wdogPeriod_65", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505ad807cead07d003a35620973c339db111", null ],
      [ "wdogPeriod_129", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a31ea334179d9e70ca0f92ea1369c74b3", null ],
      [ "wdogPeriod_257", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a272770bd44311a38300bf6d0b92ab50c", null ],
      [ "wdogPeriod_513", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a86b24d8f3bf634c9cdbbcc283d3e01e2", null ],
      [ "wdogPeriod_1k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a33a208eaf203ae5d837d296d1282249d", null ],
      [ "wdogPeriod_2k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a582f804642864a8c10ee669183fe42b9", null ],
      [ "wdogPeriod_4k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a421552f135d5094c6c84b0a741dc3f30", null ],
      [ "wdogPeriod_8k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a69df19e83f9db479572531d795cedebb", null ],
      [ "wdogPeriod_16k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a9a2fde8ebb666994e72244dab6cbd449", null ],
      [ "wdogPeriod_32k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a78630e83f49b6ab218acbfc86bdaf6c6", null ],
      [ "wdogPeriod_64k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505af993d4fb21b4a97af5d406ffdf64ebbb", null ],
      [ "wdogPeriod_128k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505ad1fde90472a0e74d6db24fe91149f5ea", null ],
      [ "wdogPeriod_256k", "dc/dc9/group___w_d_o_g.html#ggafb32176c669596071269d5fe62734505a763da9dc72d140d86dac3be63fcc77a9", null ]
    ] ],
    [ "WDOG_Enable", "dc/dc9/group___w_d_o_g.html#ga662ed794f642aac8293b7cae09c4b223", null ],
    [ "WDOG_Feed", "dc/dc9/group___w_d_o_g.html#gabf4cfa0c00f36eb71896f2ce1e884d27", null ],
    [ "WDOG_Init", "dc/dc9/group___w_d_o_g.html#ga227aa37d1eab4e7748ecc801c386c7a7", null ],
    [ "WDOG_Lock", "dc/dc9/group___w_d_o_g.html#ga26823031e069f4133964156550b64097", null ]
];