var struct_a_l_a_r_m =
[
    [ "Enabled", "d5/de0/struct_a_l_a_r_m.html#a558f5c44426d0eb7abb82a65e8892d9a", null ],
    [ "Hour", "d5/de0/struct_a_l_a_r_m.html#af3ffd946118a86464b833c200fd7771d", null ],
    [ "Minute", "d5/de0/struct_a_l_a_r_m.html#ab8eb22c6d10c66ef4b9076af23182102", null ],
    [ "Function", "d5/de0/struct_a_l_a_r_m.html#a1713dbfd96013142fa315f04dd8a01b6", null ]
];